# staticNodeExpressPortfolio
This is a portfolio of some of my projects built displayed on a page built with node and express. Some of
the projects include: quote generator, data pagination, interactive form, api requests, phrase hunters, mobile first website, connect 4 game which was built on my first portfolio, basketball stats tool, java employee management system, and a compiler written in c. You could click the links of the projects and get a live demo for most of them. This includes all of the ones with the programming languages of the web.
